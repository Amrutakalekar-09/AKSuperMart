package org.techhub.AKSupermart.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.CustomerMaster;
import org.techhub.AKSupermart.model.ProductMaster;


@Repository("custRepo")
public class CustomerRepositoryimp implements CustomerRepository{
	@Autowired
	JdbcTemplate template;
	
	@Override
	public boolean isCustlogin(final CustomerMaster cust) {
		PreparedStatementSetter pstmt = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, cust.getEmail());
				ps.setString(2, cust.getPhoneno());
			}
		};
		RowMapper<CustomerMaster> r = new RowMapper<CustomerMaster>() {

			@Override
			public CustomerMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				 CustomerMaster l = new CustomerMaster();
	                l.setCustid(rs.getInt("CustID"));
	                l.setName(rs.getString("Name"));
	                l.setEmail(rs.getString("Email"));
	                l.setPhoneno(rs.getString("Phone"));
	                l.setAddress(rs.getString("Address"));
	                return l;
			}

		};
		List<CustomerMaster> list = template.query("select * from customermaster where Email=? and Phone=?", pstmt, r);
		return list.size() > 0 ? true : false;	
	}	
	@Override
	public boolean isaddCustomer(final CustomerMaster umodel) {
		PreparedStatementSetter pstmt = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {

//				ps.setInt(1, umodel.getUid());
				ps.setString(1, umodel.getName());
				ps.setString(2, umodel.getEmail());
				ps.setString(3, umodel.getPhoneno());
				ps.setString(4, umodel.getAddress());

			}
		};
		int list = template.update("insert into CustomerMaster values('0',?,?,?,?)", pstmt);
		return list > 0 ? true : false;

	}
	
	@Override
	public List<CustomerMaster> getAllCustomer() {
		List<CustomerMaster> list = template.query("select * from CustomerMaster", new RowMapper<CustomerMaster>() {

			@Override
			public CustomerMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CustomerMaster umodel = new CustomerMaster();
				umodel.setCustid(rs.getInt(1));
				umodel.setName(rs.getString(2));
				umodel.setEmail(rs.getString(3));
				umodel.setPhoneno(rs.getString(4));
                umodel.setAddress(rs.getString(5));
				return umodel;
			}

		});
		return list.size() > 0 ? list : null;

	}
	
	@Override
	public void deleteCustomerById(String id) {
    	template.update("DELETE FROM CustomerMaster WHERE CustID='" + id + "'");

	}
	
	@Override
	public CustomerMaster getCustomerById(int custId) {
	    return template.queryForObject("select * from CustomerMaster where CustID = ?", new Object[]{custId}, new RowMapper<CustomerMaster>() {
	        @Override
	        public CustomerMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
	            CustomerMaster customer = new CustomerMaster();
	            customer.setCustid(rs.getInt(1));      // Assuming CustID is the first column
	            customer.setName(rs.getString(2));     // Name as the second column
	            customer.setEmail(rs.getString(3));    // Email as the third column
	            customer.setPhoneno(rs.getString(4));  // Phoneno as the fourth column
	            customer.setAddress(rs.getString(5));  // Address as the fifth column
	            return customer;
	        }
	    });
	}
	@Override
	public CustomerMaster getCustomerByEmail(String email) {
		return template.queryForObject("select * from CustomerMaster where Email = ?", new Object[]{email}, new RowMapper<CustomerMaster>() {
	        @Override
	        public CustomerMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
	            CustomerMaster customer = new CustomerMaster();
	            customer.setCustid(rs.getInt(1));      // Assuming CustID is the first column
	            customer.setName(rs.getString(2));     // Name as the second column
	            customer.setEmail(rs.getString(3));    // Email as the third column
	            customer.setPhoneno(rs.getString(4));  // Phoneno as the fourth column
	            customer.setAddress(rs.getString(5));  // Address as the fifth column
	            return customer;
		
	        }
		});
	}
	@Override
	public boolean updateCustomer(final CustomerMaster cust) {
	    int rowsAffected = template.update("update CustomerMaster set Name = ?, Email = ?, Phone = ?, Address = ? where CustID = ?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            
	            ps.setString(1, cust.getName());
	            ps.setString(2, cust.getEmail());
	            ps.setString(3, cust.getPhoneno());
	            ps.setString(4, cust.getAddress());
	            ps.setInt(5, cust.getCustid());
	            
	        }
	    });
	    return rowsAffected > 0;
   }
	@Override
    public List<CustomerMaster> searchCustomerByName(String name) {
        String sql = "SELECT * FROM CustomerMaster WHERE Name LIKE ?";
        return template.query(sql, new Object[]{"%" + name + "%"}, new RowMapper<CustomerMaster>() {
            @Override
            public CustomerMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
                CustomerMaster customer = new CustomerMaster();
                customer.setCustid(rs.getInt(1));      // Assuming CustID is the first column
	            customer.setName(rs.getString(2));     // Name as the second column
	            customer.setEmail(rs.getString(3));    // Email as the third column
	            customer.setPhoneno(rs.getString(4));  // Phoneno as the fourth column
	            customer.setAddress(rs.getString(5)); 
                
                return customer;
            }
        });
    }

}
