package org.techhub.AKSupermart.model;

import java.sql.Date;

public class OrderMaster {
	private int OrdId;
	private String prodId;
    private int custId;
    private Date ordDate;
    private double totalAmount;
    public OrderMaster() {
    	
    }
    public OrderMaster(String prodId, int custId, Date ordDate, double totalAmount) {
    	this.OrdId= OrdId;
        this.prodId = prodId;
        this.custId = custId;
        this.ordDate = ordDate;
        this.totalAmount = totalAmount;
        
    }
    public int getOrdId() {
		return OrdId;
	}
	public void setOrdId(int ordId) {
		OrdId = ordId;
	}
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public Date getOrdDate() {
		return ordDate;
	}
	public void setOrdDate(Date date) {
		this.ordDate = date;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
}
