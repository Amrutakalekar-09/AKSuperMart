package org.techhub.AKSupermart.Service;

import java.util.List;

import org.techhub.AKSupermart.model.BakeryitemsModel;
import org.techhub.AKSupermart.model.CategoryMaster;
import org.techhub.AKSupermart.model.ClothesModel;
import org.techhub.AKSupermart.model.ElectronicitemsModel;
import org.techhub.AKSupermart.model.GroceryModel;
import org.techhub.AKSupermart.model.KitchenitemsModel;
import org.techhub.AKSupermart.model.ProductMaster;

public interface ProductService {
	public boolean addproducts(ProductMaster model);
	public List<ProductMaster> getAllProducts();
	public void deleteProductById(String id);
	public boolean isAddGrocery(GroceryModel model);
	public boolean isAddClothes(ClothesModel model);
	public boolean isAddKitchenItems(KitchenitemsModel model);
	public boolean isAddElectronicItems(ElectronicitemsModel model);
	public boolean isAddBakeryItems(BakeryitemsModel model);
	public List<KitchenitemsModel> getkitchenitems();
	public List<GroceryModel> getgroceryitems();
	public List<ClothesModel> getclothesitems();
	public List<ElectronicitemsModel> getelectronicitems();
	public List<BakeryitemsModel> getbakeryitems();
	public void deleteGrocryById(String id);
	public void deleteClothesById(String id);
	public void deleteKitchenItemsById(String id);
	public void deleteElectronicItemsById(String id); 
	public void deleteBakeryItemsById(String id);
	public List<ProductMaster> searchProductsByName(String name); 
	public List<GroceryModel> searchGroceryItemsByProdID(String prodID);
	public List<ClothesModel> searchClothesItemsByProdID(String prodID);
	public List<KitchenitemsModel> searchKitchenItemsByProdID(String prodID);
	public List<ElectronicitemsModel> searchElectronicItemsByProdID(String prodID);
	public List<BakeryitemsModel> searchBakeryItemsByProdID(String prodID);
	public ProductMaster getProductById(String prodId);
	public boolean updateProduct(final ProductMaster product);
	public GroceryModel getGroceryItemById(String prodId);
	public ClothesModel getClothesItemById(String prodId);
	public KitchenitemsModel getKitchenItemById(String prodId);
	public ElectronicitemsModel getElectronicItemById(String prodId);
	public BakeryitemsModel getBakeryItemById(String prodId);
	public boolean updateGroceryItem(GroceryModel model);
	public boolean updateClothesItem(ClothesModel model);
	public boolean updateKitchenItems(KitchenitemsModel model);
	public boolean updateElectronicItems(ElectronicitemsModel model);
	public boolean updateBakeryItems(BakeryitemsModel model);
	 public List<ProductMaster> getProducts();
	public ProductMaster getProductByName(String productName);
	public String getProductId(String productName);
	 public double getProductPrice(String productName);
}
