package org.techhub.AKSupermart.Service;

import org.techhub.AKSupermart.model.ContactForm;

public interface ContactService {
	public void sendEmail(ContactForm contactForm);
}
