package org.techhub.AKSupermart.Repository;

import org.techhub.AKSupermart.model.RegisterMaster;

public interface RegisterRepository {
    

	public boolean isAddRegister(RegisterMaster register);
}
