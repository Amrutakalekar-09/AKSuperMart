package org.techhub.AKSupermart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.AdminRepository;
import org.techhub.AKSupermart.model.AdminMaster;
@Service
public class AdminServiceimp implements AdminService{
	@Autowired
    private AdminRepository adminRepo;
	@Override
	public boolean isAdminlogin(AdminMaster ad) {
		return adminRepo.isAdminlogin(ad);
	}
}
