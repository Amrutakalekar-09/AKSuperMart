package org.techhub.AKSupermart.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.RegisterMaster;




@Repository("regRepo")
public class RegisterRepositoryimp implements RegisterRepository{
	@Autowired
	JdbcTemplate template;
	
	@Override
	public boolean isAddRegister(final RegisterMaster register) {
	   int value=template.update("insert into register values('0',?,?,?,?)",new PreparedStatementSetter() {

		@Override
		public void setValues(PreparedStatement ps) throws SQLException {
			   ps.setString(1,register.getUsername());
			   ps.setString(2,register.getEmail());
			   ps.setString(3,register.getPassword());
			   ps.setString(4,register.getConfpassword());
		}
	   });
	   return value>0?true:false;
	}
   
}
