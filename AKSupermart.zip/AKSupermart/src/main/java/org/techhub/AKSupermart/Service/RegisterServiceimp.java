package org.techhub.AKSupermart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.RegisterRepository;
import org.techhub.AKSupermart.model.RegisterMaster;

@Service
public class RegisterServiceimp implements RegisterService{
	@Autowired
    private RegisterRepository regRepo;
	
    
	@Override
	public boolean isAddRegister(RegisterMaster register) {
		return regRepo.isAddRegister(register);
	}
   
}
