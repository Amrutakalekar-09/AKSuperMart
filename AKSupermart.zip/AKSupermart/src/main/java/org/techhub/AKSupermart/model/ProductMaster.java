package org.techhub.AKSupermart.model;

public class ProductMaster {
	    private String prodID;
	    private String prodName;
	    private int catId;
	    private double price;
	    private int quantity;
	    private String rackno;
	    private String description;
	    private String imageURL;
	    private String offer;
	    public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getImageURL() {
			return imageURL;
		}
		public void setImageURL(String imageURL) {
			this.imageURL = imageURL;
		}
		public String getOffer() {
			return offer;
		}
		public void setOffer(String offer) {
			this.offer = offer;
		}
		public ProductMaster() {
	    	
	    }
	    public ProductMaster(String prodID, String prodName, int catId, double price, int quantity, String rackno ,String description,String imageURL,String offer) {
	        this.prodID = prodID;
	        this.prodName = prodName;
	        this.catId = catId;
	        this.price = price;
	        this.quantity = quantity;
	        this.rackno = rackno;
	        this.description=description;
	        this.imageURL=imageURL;
	        this.offer=offer;
	    }
		public String getProdID() {
			return prodID;
		}
		public void setProdID(String prodID) {
			this.prodID = prodID;
		}
		public String getProdName() {
			return prodName;
		}
		public void setProdName(String prodName) {
			this.prodName = prodName;
		}
		public int getCatId() {
			return catId;
		}
		public void setCatId(int catId) {
			this.catId = catId;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public String getRackno() {
			return rackno;
		}
		public void setRackno(String rackno) {
			this.rackno = rackno;
		}
}
