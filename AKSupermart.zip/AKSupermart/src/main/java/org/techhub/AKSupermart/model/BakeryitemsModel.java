package org.techhub.AKSupermart.model;



public class BakeryitemsModel extends ProductMaster{
	private int srno;
    private String prodID;
    public BakeryitemsModel() {
    	
    }
    public BakeryitemsModel(int srno,String prodID,int catid,String bmfdate,String bexpdate) {
    	this.srno=srno;
    	this.prodID=prodID;
    	this.catid=catid;
    	this.bmfdate=bmfdate;
    	this.bexpdate=bexpdate;
    }
    public int getSrno() {
		return srno;
	}
	public void setSrno(int srno) {
		this.srno = srno;
	}
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	private int catid;
    private String  bmfdate;
    private String bexpdate;
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getBmfdate() {
		return bmfdate;
	}
	public void setBmfdate(String bmfdate) {
		this.bmfdate = bmfdate;
	}
	public String getBexpdate() {
		return bexpdate;
	}
	public void setBexpdate(String bexpdate) {
		this.bexpdate = bexpdate;
	}
	
}
