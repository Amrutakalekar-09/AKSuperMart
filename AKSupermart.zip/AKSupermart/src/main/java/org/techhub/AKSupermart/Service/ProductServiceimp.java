package org.techhub.AKSupermart.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.ProductRepository;
import org.techhub.AKSupermart.model.BakeryitemsModel;
import org.techhub.AKSupermart.model.CategoryMaster;
import org.techhub.AKSupermart.model.ClothesModel;
import org.techhub.AKSupermart.model.ElectronicitemsModel;
import org.techhub.AKSupermart.model.GroceryModel;
import org.techhub.AKSupermart.model.KitchenitemsModel;
import org.techhub.AKSupermart.model.ProductMaster;

@Service
public class ProductServiceimp implements ProductService {
    
    @Autowired
    private ProductRepository prodRepo; 

    @Override
    public boolean addproducts(ProductMaster model) {
        return prodRepo.addproducts(model);
    }

	@Override
	public List<ProductMaster> getAllProducts() {
		return prodRepo.getAllProducts();
	}

	@Override
	public void deleteProductById(String id) {
		prodRepo.deleteProductById(id);
	}

	@Override
	public boolean isAddGrocery(GroceryModel model) {
		return prodRepo.isAddGrocery(model);
	}

	@Override
	public boolean isAddClothes(ClothesModel model) {
		return prodRepo.isAddClothes(model);
	}

	@Override
	public boolean isAddKitchenItems(KitchenitemsModel model) {
		return prodRepo.isAddKitchenItems(model);
	}

	@Override
	public boolean isAddElectronicItems(ElectronicitemsModel model) {
		return prodRepo.isAddElectronicItems(model);
	}

	@Override
	public boolean isAddBakeryItems(BakeryitemsModel model) {
		return prodRepo.isAddBakeryItems(model);
	}

	@Override
	public List<KitchenitemsModel> getkitchenitems() {
		return prodRepo.getkitchenitems();
	}

	@Override
	public List<GroceryModel> getgroceryitems() {
		return prodRepo.getgroceryitems();
	}

	@Override
	public List<ClothesModel> getclothesitems() {
		return prodRepo.getclothesitems();
	}

	@Override
	public List<ElectronicitemsModel> getelectronicitems() {
		return prodRepo.getelectronicitems();
	}

	@Override
	public List<BakeryitemsModel> getbakeryitems() {
		return prodRepo.getbakeryitems();
	}

	@Override
	public void deleteGrocryById(String id) {
		prodRepo.deleteGrocryById(id);
		
	}
	@Override
	public void deleteClothesById(String id) {
	    prodRepo.deleteClothesById(id);
	}

	@Override
	public void deleteKitchenItemsById(String id) {
	   prodRepo.deleteKitchenItemsById(id);
	}

	@Override
	public void deleteElectronicItemsById(String id) {
	   prodRepo.deleteElectronicItemsById(id);
	}

	@Override
	public void deleteBakeryItemsById(String id) {
	    prodRepo.deleteBakeryItemsById(id);
	}

	@Override
	public List<ProductMaster> searchProductsByName(String name) {
		return prodRepo.searchProductsByName(name);
	}

	@Override
	public ProductMaster getProductById(String prodId) {
		return prodRepo.getProductById(prodId);
	}

	@Override
	public boolean updateProduct(ProductMaster product) {
		return prodRepo.updateProduct(product);
	}
	@Override
	public boolean updateGroceryItem(GroceryModel model) {
	    return prodRepo.updateGroceryItem(model);
	}
	@Override
	public boolean updateClothesItem(ClothesModel model) {
	    return prodRepo.updateClothesItem(model);
	}
	@Override
	public boolean updateKitchenItems(KitchenitemsModel model) {
		return prodRepo.updateKitchenItems(model);
	}
	@Override
	public boolean updateElectronicItems(ElectronicitemsModel model) {
		return prodRepo.updateElectronicItems(model);
	}
	@Override
	public boolean updateBakeryItems(BakeryitemsModel model) {
		return prodRepo.updateBakeryItems(model);
	}

	@Override
	public GroceryModel getGroceryItemById(String prodId) {
		
		return prodRepo.getGroceryItemById(prodId);
	}

	@Override
	public ClothesModel getClothesItemById(String prodId) {
		
		return prodRepo.getClothesItemById(prodId);
	}

	@Override
	public KitchenitemsModel getKitchenItemById(String prodId) {
		
		return prodRepo.getKitchenItemById(prodId);
	}

	@Override
	public ElectronicitemsModel getElectronicItemById(String prodId) {
	
		return prodRepo.getElectronicItemById(prodId);
	}

	@Override
	public BakeryitemsModel getBakeryItemById(String prodId) {

		return prodRepo.getBakeryItemById(prodId);
	}

	@Override
	public List<GroceryModel> searchGroceryItemsByProdID(String prodID) {
		return prodRepo.searchGroceryItemsByProdID(prodID);
	}

	@Override
	public List<ClothesModel> searchClothesItemsByProdID(String prodID) {
		return prodRepo.searchClothesItemsByProdID(prodID);
	}

	@Override
	public List<KitchenitemsModel> searchKitchenItemsByProdID(String prodID) {
		return prodRepo.searchKitchenItemsByProdID(prodID);
	}

	@Override
	public List<ElectronicitemsModel> searchElectronicItemsByProdID(String prodID) {
		return prodRepo.searchElectronicItemsByProdID(prodID);
	}

	@Override
	public List<BakeryitemsModel> searchBakeryItemsByProdID(String prodID) {
		return prodRepo.searchBakeryItemsByProdID(prodID);
	}

	@Override
	public List<ProductMaster> getProducts() {
		
		return prodRepo.getProducts();
	}

	@Override
	public ProductMaster getProductByName(String productName) {
		// TODO Auto-generated method stub
		return prodRepo.getProductByName(productName);
	}

	@Override
	public String getProductId(String productName) {
		// TODO Auto-generated method stub
		return prodRepo.getProductId(productName);
	}

	@Override
	public double getProductPrice(String productName) {
		// TODO Auto-generated method stub
		return prodRepo.getProductPrice(productName);
	}
	
	
}
