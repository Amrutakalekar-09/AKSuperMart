package org.techhub.AKSupermart.Repository;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.BakeryitemsModel;
import org.techhub.AKSupermart.model.CategoryMaster;
import org.techhub.AKSupermart.model.ClothesModel;
import org.techhub.AKSupermart.model.ElectronicitemsModel;
import org.techhub.AKSupermart.model.GroceryModel;
import org.techhub.AKSupermart.model.KitchenitemsModel;
import org.techhub.AKSupermart.model.ProductMaster;




@Repository
public class ProductRepositoryimp implements ProductRepository {

    @Autowired
    JdbcTemplate template;

    @Override
    public boolean addproducts(final ProductMaster model) {
    	
    	int list = template.update("insert into ProductMaster values(?, ?, ?, ?, ?, ?,?,?,?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1, model.getProdID());
                ps.setString(2, model.getProdName());
                ps.setInt(3, model.getCatId());
                ps.setDouble(4, model.getPrice());
                ps.setInt(5, model.getQuantity());
                ps.setString(6, model.getRackno());
                ps.setString(7, model.getImageURL());
                ps.setString(8, model.getDescription());
                ps.setString(9, model.getOffer());
            }
    	});
         return list>0?true:false;
    }
    
    @Override
    public boolean isAddGrocery(final GroceryModel model) {
    	int list = template.update("insert into grocery values ('0',?, ?, ?, ?,?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
    			ps.setString(1, model.getProdID());
                ps.setInt(2, model.getCatid());
                ps.setString(3, model.getMfdate());
                ps.setString(4, model.getExpdate());
                ps.setString(5, model.getWeight());
    		}
    	});
        return list>0?true:false;
    }
    
    @Override
    public boolean isAddClothes(final ClothesModel model) {
    	int list = template.update("insert into clothes values ('0',?, ?, ?, ?, ?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
    			 ps.setString(1, model.getProdID());
   	             ps.setInt(2, model.getCatid());
   	             ps.setString(3, model.getSize());
   	             ps.setString(4, model.getColour());
   	             ps.setString(5, model.getCbrand());
    		}
    	});
        return list>0?true:false;
    }
    
    @Override
    public boolean isAddKitchenItems(final KitchenitemsModel model) {
    	int list = template.update("insert into kitchenitems values ('0',? ,?, ?, ?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
    			 ps.setString(1, model.getProdID());
    	         ps.setInt(2, model.getCatid());
    	         ps.setString(3, model.getKMaterial());
    	         ps.setString(4, model.getKBrand());
    		}
    	});
        return list>0?true:false;
    }
    
    @Override
    public boolean isAddElectronicItems(final ElectronicitemsModel model) {
    	int list = template.update("insert into electronicitems values ('0',?, ?, ?, ?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
    			ps.setString(1, model.getProdID());
                ps.setInt(2, model.getCatid());
                ps.setString(3, model.getEBrand());
                ps.setString(4, model.getEWarranty());
    		}
    	});
        return list>0?true:false;
    }
    
    @Override
    public boolean isAddBakeryItems(final BakeryitemsModel model) {
    	int list = template.update("insert into bakeryitems values ('0',?,?, ?, ?)",new PreparedStatementSetter() {
    		@Override
            public void setValues(PreparedStatement ps) throws SQLException {
    			ps.setString(1, model.getProdID());
                ps.setInt(2, model.getCatid());
                ps.setString(3, model.getBmfdate());
                ps.setString(4, model.getBexpdate());
    		}
    	});
        return list>0?true:false;
    }
    
    @Override
    public List<ProductMaster> getAllProducts() {
		List<ProductMaster> list = template.query("select * from ProductMaster", new RowMapper<ProductMaster>() {

			@Override
			public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ProductMaster model = new ProductMaster();
				model.setProdID(rs.getString(1));
				model.setProdName(rs.getString(2));
				model.setCatId(rs.getInt(3));
				model.setPrice(rs.getDouble(4));
				model.setQuantity(rs.getInt(5));
				model.setRackno(rs.getString(6));
                model.setImageURL(rs.getString(7));
                model.setImageURL(rs.getString(8));
                model.setOffer(rs.getString(9));
				return model;
			}

		});
		return list.size() > 0 ? list : null;

	}
    
    @Override
	public void deleteProductById(String id) {
    	template.update("DELETE FROM ProductMaster WHERE ProdID='" + id + "'");

	}
    
    @Override
    public List<KitchenitemsModel> getkitchenitems() {
		List<KitchenitemsModel> list = template.query("select * from kitchenitems", new RowMapper<KitchenitemsModel>() {

			@Override
			public KitchenitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				KitchenitemsModel model = new KitchenitemsModel();
				model.setSrno(rs.getInt(1));
				model.setProdID(rs.getString(2));
				model.setCatId(rs.getInt(3));
				model.setKMaterial(rs.getString(4));
                model.setKBrand(rs.getString(5));
				return model;
			}

		});
		return list.size() > 0 ? list : null;

	}
   

	@Override
	public List<GroceryModel> getgroceryitems() {
		List<GroceryModel> list = template.query("select * from grocery", new RowMapper<GroceryModel>() {

			@Override
			public GroceryModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				GroceryModel model = new GroceryModel();
				model.setSrno(rs.getInt(1));
				model.setProdID(rs.getString(2));
				model.setCatId(rs.getInt(3));
				model.setMfdate(rs.getString(4));
				model.setExpdate(rs.getString(5));
				model.setWeight(rs.getString(6));
				return model;
			}

		});
		return list.size() > 0 ? list : null;
	}

	@Override
	public List<ClothesModel> getclothesitems() {
		List<ClothesModel> list = template.query("select * from clothes", new RowMapper<ClothesModel>() {

			@Override
			public ClothesModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				ClothesModel model = new ClothesModel();
				model.setSrno(rs.getInt(1));
				model.setProdID(rs.getString(2));
				model.setCatId(rs.getInt(3));
		        model.setSize(rs.getString(4));
		        model.setColour(rs.getString(5));
		        model.setCbrand(rs.getString(6));
				return model;
			}

		});
		return list.size() > 0 ? list : null;
	}

	@Override
	public List<ElectronicitemsModel> getelectronicitems() {
		List<ElectronicitemsModel> list = template.query("select * from electronicitems", new RowMapper<ElectronicitemsModel>() {

			@Override
			public ElectronicitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				ElectronicitemsModel model = new ElectronicitemsModel();
				model.setSrno(rs.getInt(1));
				model.setProdID(rs.getString(2));
				model.setCatId(rs.getInt(3));
				model.setEBrand(rs.getString(4));
				model.setEWarranty(rs.getString(5));
				return model;
			}

		});
		return list.size() > 0 ? list : null;
	}

	@Override
	public List<BakeryitemsModel> getbakeryitems() {
		List<BakeryitemsModel> list = template.query("select * from bakeryitems", new RowMapper<BakeryitemsModel>() {

			@Override
			public BakeryitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				BakeryitemsModel model = new BakeryitemsModel();
				model.setSrno(rs.getInt(1));
				model.setProdID(rs.getString(2));
				model.setCatId(rs.getInt(3));
				model.setBmfdate(rs.getString(4));
				model.setBexpdate(rs.getString(5));
				return model;
			}

		});
		return list.size() > 0 ? list : null;
	
	}
	@Override
	public void deleteGrocryById(String id) {
    	template.update("DELETE FROM grocery WHERE ProdID='" + id + "'");

	}
	@Override
	public void deleteClothesById(String id) {
	    template.update("DELETE FROM clothes WHERE ProdID=?", id);
	}

	@Override
	public void deleteKitchenItemsById(String id) {
	    template.update("DELETE FROM kitchenitems WHERE ProdID=?", id);
	}

	@Override
	public void deleteElectronicItemsById(String id) {
	    template.update("DELETE FROM electronicitems WHERE ProdID=?", id);
	}

	@Override
	public void deleteBakeryItemsById(String id) {
	    template.update("DELETE FROM bakeryitems WHERE ProdID=?", id);
	}
	
	@Override
    public List<ProductMaster> searchProductsByName(String name) {
        String sql = "SELECT * FROM ProductMaster WHERE ProdName LIKE ?";
        return template.query(sql, new Object[]{"%" + name + "%"}, new RowMapper<ProductMaster>() {
            @Override
            public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
                ProductMaster model = new ProductMaster();
                model.setProdID(rs.getString("ProdID"));
                model.setProdName(rs.getString("ProdName"));
                model.setCatId(rs.getInt("CatID"));
                model.setPrice(rs.getDouble("Price"));
                model.setQuantity(rs.getInt("Quantity"));
                model.setRackno(rs.getString("Rackno"));
                model.setImageURL(rs.getString("ImageURL"));
                model.setDescription(rs.getString("Description"));
                model.setOffer(rs.getString("Offer"));
                return model;
            }
        });
    }
	@Override
	public List<GroceryModel> searchGroceryItemsByProdID(String prodID) {
	    String sql = "SELECT * FROM grocery WHERE ProdID LIKE ?";
	    return template.query(sql, new Object[]{"%" + prodID + "%"}, new RowMapper<GroceryModel>() {
	        @Override
	        public GroceryModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            GroceryModel model = new GroceryModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatid(rs.getInt("CatID"));
	            model.setMfdate(rs.getString("ManifacturDate")); 
	            model.setExpdate(rs.getString("ExpiryDate"));
	            model.setWeight(rs.getString("Weight"));
	            return model;
	        }
	    });
	}
	
	@Override
	public List<ClothesModel> searchClothesItemsByProdID(String prodID) {
	    String sql = "SELECT * FROM clothes WHERE ProdID LIKE ?";
	    return template.query(sql, new Object[]{"%" + prodID + "%"}, new RowMapper<ClothesModel>() {
	        @Override
	        public ClothesModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	        	ClothesModel model = new ClothesModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setSize(rs.getString("Size"));
	            model.setColour(rs.getString("Color"));
	            model.setCbrand(rs.getString("Brand"));
	            return model;
	        }
	    });
	}

    
	@Override
	public List<KitchenitemsModel> searchKitchenItemsByProdID(String prodID) {
	    String sql = "SELECT * FROM kitchenitems WHERE ProdID LIKE ?";
	    return template.query(sql, new Object[]{"%" + prodID + "%"}, new RowMapper<KitchenitemsModel>() {
	        @Override
	        public KitchenitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            KitchenitemsModel model = new KitchenitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setKMaterial(rs.getString("Material"));
	            model.setKBrand(rs.getString("Brand"));
	            return model;
	        }
	    });
	}

	
	@Override
	public List<ElectronicitemsModel> searchElectronicItemsByProdID(String prodID) {
	    String sql = "SELECT * FROM electronicitems WHERE ProdID LIKE ?";
	    return template.query(sql, new Object[]{"%" + prodID + "%"}, new RowMapper<ElectronicitemsModel>() {
	        @Override
	        public ElectronicitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            ElectronicitemsModel model = new ElectronicitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setEBrand(rs.getString("Brand"));
	            model.setEWarranty(rs.getString("WarrantyPeriod"));
	            return model;
	        }
	    });
	}

	
	@Override
	public List<BakeryitemsModel> searchBakeryItemsByProdID(String prodID) {
	    String sql = "SELECT * FROM bakeryitems WHERE ProdID LIKE ?";
	    return template.query(sql, new Object[]{"%" + prodID + "%"}, new RowMapper<BakeryitemsModel>() {
	        @Override
	        public BakeryitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            BakeryitemsModel model = new BakeryitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setBmfdate(rs.getString("ManifacturDate"));
	            model.setBexpdate(rs.getString("ExpiryDate"));
	            return model;
	        }
	    });
	}

	
	@Override
	public ProductMaster getProductById(String prodId) {
	    return template.queryForObject("select * from ProductMaster where prodID = ?", new Object[]{prodId}, new RowMapper<ProductMaster>() {
	        @Override
	        public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
	            ProductMaster product = new ProductMaster();
	            product.setProdID(rs.getString(1));
	            product.setProdName(rs.getString(2));
	            product.setCatId(rs.getInt(3));
	            product.setPrice(rs.getDouble(4));
	            product.setQuantity(rs.getInt(5));
	            product.setRackno(rs.getString(6));
	            product.setImageURL(rs.getString(7));
	            product.setDescription(rs.getString(8));
	            product.setOffer(rs.getString(9));
	            return product;
	        }
	    });
	}
	@Override
	public boolean updateProduct(final ProductMaster product) {
	    int rowsAffected = template.update("update ProductMaster set ProdName = ?, CatId = ?, Price = ?, Quantity = ?, Rackno = ?, ImageURL = ?, Description = ?, Offer = ? where ProdID = ?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, product.getProdName());
	            ps.setInt(2, product.getCatId());
	            ps.setDouble(3, product.getPrice());
	            ps.setInt(4, product.getQuantity());
	            ps.setString(5, product.getRackno());
	            ps.setString(6, product.getImageURL());
	            ps.setString(7, product.getDescription());
	            ps.setString(8, product.getOffer());
	            ps.setString(9, product.getProdID());
	        }
	    });
	    return rowsAffected > 0;
   }
    
	
	@Override
	public GroceryModel getGroceryItemById(String prodId) {
	    return template.queryForObject("SELECT * FROM grocery WHERE ProdID = ?", new Object[]{prodId}, new RowMapper<GroceryModel>() {
	        @Override
	        public GroceryModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            GroceryModel model = new GroceryModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatid(rs.getInt("CatID"));
	            model.setMfdate(rs.getString("ManifacturDate")); // Correct column name
	            model.setExpdate(rs.getString("ExpiryDate"));
	            model.setWeight(rs.getString("Weight"));
	            return model;
	        }
	    });
	}

    
	@Override
	public ClothesModel getClothesItemById(String prodId) {
	    return template.queryForObject("SELECT * FROM clothes WHERE ProdID = ?", new Object[]{prodId}, new RowMapper<ClothesModel>() {
	        @Override
	        public ClothesModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            ClothesModel model = new ClothesModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setSize(rs.getString("Size"));
	            model.setColour(rs.getString("Color"));
	            model.setCbrand(rs.getString("Brand"));
	            return model;
	        }
	    });
	}
 
	@Override
	public KitchenitemsModel getKitchenItemById(String prodId) {
	    return template.queryForObject("SELECT * FROM kitchenitems WHERE ProdID = ?", new Object[]{prodId}, new RowMapper<KitchenitemsModel>() {
	        @Override
	        public KitchenitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            KitchenitemsModel model = new KitchenitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setKMaterial(rs.getString("Material"));
	            model.setKBrand(rs.getString("Brand"));
	            return model;
	        }
	    });
	}

	@Override
	public ElectronicitemsModel getElectronicItemById(String prodId) {
	    return template.queryForObject("SELECT * FROM electronicitems WHERE ProdID = ?", new Object[]{prodId}, new RowMapper<ElectronicitemsModel>() {
	        @Override
	        public ElectronicitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            ElectronicitemsModel model = new ElectronicitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setEBrand(rs.getString("Brand"));
	            model.setEWarranty(rs.getString("WarrantyPeriod"));
	            return model;
	        }
	    });
	}

	
	@Override
	public BakeryitemsModel getBakeryItemById(String prodId) {
	    return template.queryForObject("SELECT * FROM bakeryitems WHERE ProdID = ?", new Object[]{prodId}, new RowMapper<BakeryitemsModel>() {
	        @Override
	        public BakeryitemsModel mapRow(ResultSet rs, int rowNum) throws SQLException {
	            BakeryitemsModel model = new BakeryitemsModel();
	            model.setSrno(rs.getInt("Srno"));
	            model.setProdID(rs.getString("ProdID"));
	            model.setCatId(rs.getInt("CatID"));
	            model.setBmfdate(rs.getString("ManifacturDate"));
	            model.setBexpdate(rs.getString("ExpiryDate"));
	            return model;
	        }
	    });
	}

	@Override
	public boolean updateGroceryItem(final GroceryModel model) {
	    int result = template.update("UPDATE grocery SET ManifacturDate=?, ExpiryDate=?, Weight=? WHERE ProdID=?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, model.getMfdate());
	            ps.setString(2, model.getExpdate());
	            ps.setString(3, model.getWeight());
	            ps.setString(4, model.getProdID());
	        }
	    });
	    return result > 0;
	}

	
	@Override
	public boolean updateClothesItem(final ClothesModel model) {
	    int result = template.update("UPDATE clothes SET Size=?, Color=?, Brand=? WHERE ProdID=?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, model.getSize());
	            ps.setString(2, model.getColour());
	            ps.setString(3, model.getCbrand());
	            ps.setString(4, model.getProdID());
	        }
	    });
	    return result > 0;
	}

	@Override
	public boolean updateKitchenItems(final KitchenitemsModel model) {
	    int result = template.update("UPDATE kitchenitems SET Material=?, Brand=? WHERE ProdID=?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, model.getKMaterial());
	            ps.setString(2, model.getKBrand());
	            ps.setString(3, model.getProdID());
	        }
	    });
	    return result > 0;
	}

	@Override
	public boolean updateElectronicItems(final ElectronicitemsModel model) {
	    int result = template.update("UPDATE electronicitems SET Brand=?, WarrantyPeriod=? WHERE ProdID=?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, model.getEBrand());
	            ps.setString(2, model.getEWarranty());
	            ps.setString(3, model.getProdID());
	        }
	    });
	    return result > 0;
	}

	@Override
	public boolean updateBakeryItems(final BakeryitemsModel model) {
	    int result = template.update("UPDATE bakeryitems SET ManifacturDate=?, ExpiryDate=? WHERE ProdID=?", new PreparedStatementSetter() {
	        @Override
	        public void setValues(PreparedStatement ps) throws SQLException {
	            ps.setString(1, model.getBmfdate());
	            ps.setString(2, model.getBexpdate());
	            ps.setString(3, model.getProdID());
	        }
	    });
	    return result > 0;
	}

	@Override
    public List<ProductMaster> getProducts() {
		List<ProductMaster> list = template.query("select imageURL,ProdName,description,price,offer,CatID from ProductMaster", new RowMapper<ProductMaster>() {

			@Override
			public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			   ProductMaster model = new ProductMaster();
				
                model.setImageURL(rs.getString(1));
                model.setProdName(rs.getString(2));
                model.setDescription(rs.getString(3));
                model.setPrice(rs.getDouble(4));
                model.setOffer(rs.getString(5));
                model.setCatId(rs.getInt(6));
				return model;
			}

		});
		return list.size() > 0 ? list : null;

	}
	@Override
	public ProductMaster getProductByName(String productName) {
	    String sql = "SELECT * FROM productmaster WHERE ProdName = ?";
	    
	    try {
	        // Use queryForObject to directly fetch a single result
	        return template.queryForObject(sql, new Object[]{productName}, new RowMapper<ProductMaster>() {
	            @Override
	            public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
	                ProductMaster model = new ProductMaster();
	                model.setProdID(rs.getString(1));
					model.setProdName(rs.getString(2));
					model.setCatId(rs.getInt(3));
					model.setPrice(rs.getDouble(4));
					model.setQuantity(rs.getInt(5));
					model.setRackno(rs.getString(6));
	                model.setImageURL(rs.getString(7));
	                model.setImageURL(rs.getString(8));
	                model.setOffer(rs.getString(9));
	                
	                return model;
	            }
	        });
	    } catch (EmptyResultDataAccessException e) {
	        // No product found with the given name
	        return null;
	    }
	}
	
	@Override
	public String getProductId(String productName) {
	    String sql = "SELECT ProdID FROM productmaster WHERE ProdName = ?";
	    
	    try {
	        // Use queryForObject to directly fetch a single result
	        return template.queryForObject(sql, new Object[]{productName}, String.class);
	    } catch (EmptyResultDataAccessException e) {
	        // No product found with the given name
	        return null;
	    }
	}
	@Override
	public double getProductPrice(String productName) {
	    String sql = "SELECT Price FROM productmaster WHERE ProdName = ?";
	    
	    try {
	        // Use queryForObject to directly fetch a single result
	        return template.queryForObject(sql, new Object[]{productName}, Double.class);
	    } catch (EmptyResultDataAccessException e) {
	        // No product found with the given name
	        return 0.0;
	    }
	}

	
}
