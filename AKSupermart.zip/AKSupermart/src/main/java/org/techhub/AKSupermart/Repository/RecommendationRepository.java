package org.techhub.AKSupermart.Repository;

import java.util.List;

import org.techhub.AKSupermart.model.ProductMaster;

public interface RecommendationRepository {

	ProductMaster getProductIdByName(String productName);
    List<Integer> getCustomerIdsByProductId(String productId);
    List<String> getOtherProductsByCustomerId(int customerId, String productId);
    public ProductMaster getProductByName(String productName);
    public String getProductNameById(String productId);
}
