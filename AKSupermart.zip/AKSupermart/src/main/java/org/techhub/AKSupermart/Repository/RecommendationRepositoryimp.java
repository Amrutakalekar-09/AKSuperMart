package org.techhub.AKSupermart.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.ProductMaster;

import java.util.List;

@Repository
public class RecommendationRepositoryimp implements RecommendationRepository {
	
    @Autowired
    JdbcTemplate template;

 // Get product details by product name
    @Override
    public ProductMaster getProductIdByName(String productName) {
        List<ProductMaster> products = template.query(
            "SELECT ProdID FROM productmaster WHERE ProdName = ?",
            new Object[]{productName},
            new RowMapper<ProductMaster>() {
                @Override
                public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ProductMaster product = new ProductMaster();
                    product.setProdID(rs.getString("ProdID"));  // Set the ProdID
                    return product;  // Return the populated ProductMaster object
                }
            }
        );

        // Check if a product was found
        if (products.isEmpty()) {
            return null; // No product found
        }
        return products.get(0); // Return the first (and ideally only) product
    }


    // Get a list of customer IDs who ordered a specific product
    @Override
    public List<Integer> getCustomerIdsByProductId(String productId) {
        String sql = "SELECT DISTINCT CustID FROM ordermaster WHERE ProdID = ?";
        return template.query(sql, new Object[]{productId}, new RowMapper<Integer>() {
            @Override
            public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getInt("CustID");
            }
        });
    }

    // Get a list of other products ordered by a customer, excluding a specific product
    @Override
    public List<String> getOtherProductsByCustomerId(int customerId, String productId) {
        String sql = "SELECT ProdName FROM productmaster WHERE ProdID IN (SELECT ProdID FROM ordermaster WHERE CustID = ? AND ProdID != ?)";
        return template.query(sql, new Object[]{customerId, productId}, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("ProdName");
            }
        });
    }

    // Get the product name by product ID
    @Override
    public String getProductNameById(String productId) {
        String sql = "SELECT ProdName FROM productmaster WHERE ProdID = ?";
        return template.queryForObject(sql, new Object[]{productId}, String.class);
    }
    
 // Repository method to get product details by product name
    @Override
    public ProductMaster getProductByName(String productName) {
        List<ProductMaster> products = template.query(
            "SELECT * FROM productmaster WHERE ProdName = ?",
            new Object[]{productName},
            new RowMapper<ProductMaster>() {
                @Override
                public ProductMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ProductMaster product = new ProductMaster();
                    product.setProdID(rs.getString("ProdID"));
                    product.setProdName(rs.getString("ProdName"));
                    product.setDescription(rs.getString("Description"));
                    product.setPrice(rs.getDouble("Price"));
                    product.setOffer(rs.getString("Offer"));
                    product.setImageURL(rs.getString("ImageURL")); // Ensure this field exists in your table
                    product.setCatId(rs.getInt("CatID"));
                    return product;
                }
            }
        );

        if (products.isEmpty()) {
            return null;
        }
        return products.get(0);
    }

}
