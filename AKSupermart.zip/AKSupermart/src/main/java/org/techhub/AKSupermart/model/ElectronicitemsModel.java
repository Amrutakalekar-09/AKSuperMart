package org.techhub.AKSupermart.model;

public class ElectronicitemsModel extends ProductMaster{
	private int srno;
    private String prodID;
    public  ElectronicitemsModel() {
    	
    }
    public  ElectronicitemsModel(int srno,String prodID,int catid,String EBrand,String EWarranty) {
    	this.srno=srno;
    	this.prodID=prodID;
    	this.catid=catid;
    	this.EBrand=EBrand;
    	this.EWarranty=EWarranty;
    }
    public int getSrno() {
		return srno;
	}
	public void setSrno(int srno) {
		this.srno = srno;
	}
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	private int catid;
    private String EBrand;
    private String EWarranty;
	
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getEBrand() {
		return EBrand;
	}
	public void setEBrand(String eBrand) {
		EBrand = eBrand;
	}
	public String getEWarranty() {
		return EWarranty;
	}
	public void setEWarranty(String eWarranty) {
		EWarranty = eWarranty;
	}
	
}
