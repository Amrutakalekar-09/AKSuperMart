package org.techhub.AKSupermart.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.ContactForm;

@Repository
public class ContactRepositoryimp implements ContactRepository {
    
    @Autowired
    private JavaMailSender emailSender;

    @Override
    public void sendEmail(ContactForm contactForm) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo("kalekaramruta09@gmail.com"); // Replace with your actual email address
            message.setSubject("Contact Form Submission from " + contactForm.getName());
            message.setText("Name: " + contactForm.getName() + "\n" +
                            "Email: " + contactForm.getEmail() + "\n" +
                            "Phone Number: " + contactForm.getPhone() + "\n" +
                            "Message:\n" + contactForm.getMessage());

            emailSender.send(message);
            System.out.println("Email sent successfully!");
        } catch (Exception e) {
            System.err.println("Error while sending email: " + e.getMessage());
        }
    }
}
