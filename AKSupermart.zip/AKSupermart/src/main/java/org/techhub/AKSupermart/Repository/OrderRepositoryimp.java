package org.techhub.AKSupermart.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.OrderMaster;



@Repository
public class OrderRepositoryimp implements OrderRepository{
	@Autowired
    JdbcTemplate template;
	
	@Override
	public boolean saveOrder(OrderMaster order) {
        String sql = "INSERT INTO ordermaster (ProdID, CustID, OrdDate, TotalAmount) VALUES (?, ?, ?, ?)";
        int rowsAffected = template.update(sql, order.getProdId(), order.getCustId(), order.getOrdDate(), order.getTotalAmount());
        return rowsAffected > 0;
    }
	@Override
    public List<OrderMaster> getCustomerwiseOrders(int custId) {
        String sql = "SELECT * FROM OrderMaster WHERE CustID = ?";
        return template.query(sql, new Object[]{custId}, new OrderMasterRowMapper());
    }

    private static class OrderMasterRowMapper implements RowMapper<OrderMaster> {
        @Override
        public OrderMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
            OrderMaster order = new OrderMaster();
            order.setOrdId(rs.getInt("OrdID"));
            order.setProdId(rs.getString("ProdID"));
            order.setCustId(rs.getInt("CustID"));
            order.setOrdDate(rs.getDate("OrdDate"));
            order.setTotalAmount(rs.getDouble("TotalAmount"));
            return order;
        }
    }

//    @Override
//    public boolean addorder(final OrderMaster model) {
//    	
//    	int list = template.update("insert into ordermaster values(?, ?, ?, ?, ?)",new PreparedStatementSetter() {
//    		@Override
//            public void setValues(PreparedStatement ps) throws SQLException {
//                ps.setInt(1, model.getOrdId());
//                ps.setString(2, model.getProdId());
//                ps.setInt(3, model.getCustId());
//                ps.setDate(4, model.getOrdDate());
//                ps.setDouble(5, model.getTotalAmount());
//            }
//    	});
//         return list>0?true:false;
//    }
//
	@Override
	public List<OrderMaster> getAllOrder() {
		List<OrderMaster> list = template.query("select * from ordermaster", new RowMapper<OrderMaster>() {

			@Override
			public OrderMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				OrderMaster model = new OrderMaster();
				model.setOrdId(rs.getInt(1));
				model.setProdId(rs.getString(2));
				model.setCustId(rs.getInt(3));
				model.setOrdDate(rs.getDate(4));
				model.setTotalAmount(rs.getDouble(5));
				return model;
			}

		});
		return list.size() > 0 ? list : null;
	}
	
	
}
