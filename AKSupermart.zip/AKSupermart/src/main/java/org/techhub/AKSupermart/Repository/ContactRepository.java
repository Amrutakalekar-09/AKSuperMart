package org.techhub.AKSupermart.Repository;

import org.techhub.AKSupermart.model.ContactForm;

public interface ContactRepository {
	 public void sendEmail(ContactForm contactForm);
}
