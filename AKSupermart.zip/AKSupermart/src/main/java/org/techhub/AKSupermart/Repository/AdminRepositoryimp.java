package org.techhub.AKSupermart.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.techhub.AKSupermart.model.AdminMaster;


@Repository("adminRepo")
public class AdminRepositoryimp implements AdminRepository{
	@Autowired
	JdbcTemplate template;
	
	@Override
	public boolean isAdminlogin(final AdminMaster ad) {
		PreparedStatementSetter pstmt = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, ad.getUsername());
				ps.setString(2, ad.getPassword());
			}
		};
		RowMapper<AdminMaster> r = new RowMapper<AdminMaster>() {

			@Override
			public AdminMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				 AdminMaster a = new AdminMaster();
	                a.setId(rs.getInt("id"));
	                a.setUsername(rs.getString("username"));
	                a.setPassword(rs.getString("password"));
	                return a;
			}

		};
		List<AdminMaster> list = template.query("select * from  admin_users  where username=? and password=?", pstmt, r);
		return list.size() > 0 ? true : false;	
	}
	

}
