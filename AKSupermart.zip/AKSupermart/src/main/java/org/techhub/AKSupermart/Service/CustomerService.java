package org.techhub.AKSupermart.Service;

import java.util.List;

import org.techhub.AKSupermart.model.CustomerMaster;

public interface CustomerService {
	public boolean isCustlogin(CustomerMaster cust);
	public boolean isaddCustomer(final CustomerMaster umodel);
	public List<CustomerMaster> getAllCustomer();
	public void deleteCustomerById(String id);
	public CustomerMaster getCustomerById(int custId);
	public CustomerMaster getCustomerByEmail(String email);
	public boolean updateCustomer(final CustomerMaster cust);
	public List<CustomerMaster> searchCustomerByName(String name);
}
