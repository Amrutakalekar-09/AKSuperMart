package org.techhub.AKSupermart.model;



public class GroceryModel extends ProductMaster {
    private int srno;
    private String prodID;
    private int catid;
    private String mfdate;
    private String expdate;
    private String weight;
    
    public String getWeight() {
		return weight;
	}


	public void setWeight(String weight) {
		this.weight = weight;
	}


	public GroceryModel() {
    	
    }

    
    public GroceryModel(int srno, String prodID, int catid, String mfdate, String expdate, String weight) {
        this.srno = srno;
        this.prodID = prodID;
        this.catid = catid;
        this.mfdate = mfdate;
        this.expdate = expdate;
        this.weight=weight;
    }
    

    public int getSrno() {
        return srno;
    }

    public void setSrno(int srno) {
        this.srno = srno;
    }

    public String getProdID() {
        return prodID;
    }

    public void setProdID(String prodID) {
        this.prodID = prodID;
    }

    public int getCatid() {
        return catid;
    }

    public void setCatid(int catid) {
        this.catid = catid;
    }

    public String getMfdate() {
        return mfdate;
    }

    public void setMfdate(String mfdate) {
        this.mfdate = mfdate;
    }

    public String getExpdate() {
        return expdate;
    }

    public void setExpdate(String expdate) {
        this.expdate = expdate;
    }

   
}
