package org.techhub.AKSupermart.Service;

import java.util.LinkedHashSet;
import java.util.List;

import org.techhub.AKSupermart.model.ProductMaster;

public interface RecommendationService {
	 List<ProductMaster> getRecommendations(String productName);

	 public ProductMaster getProductByName(String productName);
}
