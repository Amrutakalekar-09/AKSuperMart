package org.techhub.AKSupermart.model;

public class CartItem {
    private ProductMaster product;
    private int quantity;

    public CartItem(ProductMaster product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public ProductMaster getProduct() {
        return product;
    }

    public void setProduct(ProductMaster product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return product.getPrice() * quantity;
    }
}

