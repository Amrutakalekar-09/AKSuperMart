package org.techhub.AKSupermart.Service;

import org.techhub.AKSupermart.model.RegisterMaster;

public interface RegisterService {
    public boolean isAddRegister(RegisterMaster register);
}
