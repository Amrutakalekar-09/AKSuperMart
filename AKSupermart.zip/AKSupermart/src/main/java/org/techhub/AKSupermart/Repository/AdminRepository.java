package org.techhub.AKSupermart.Repository;

import org.techhub.AKSupermart.model.AdminMaster;

public interface AdminRepository {
	public boolean isAdminlogin(AdminMaster ad);
}
