package org.techhub.AKSupermart.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.techhub.AKSupermart.Service.AdminService;
import org.techhub.AKSupermart.Service.ContactService;
import org.techhub.AKSupermart.Service.CustomerService;
import org.techhub.AKSupermart.Service.OrderService;
import org.techhub.AKSupermart.Service.ProductService;
import org.techhub.AKSupermart.Service.RecommendationService;
import org.techhub.AKSupermart.Service.RegisterService;
import org.techhub.AKSupermart.model.AdminMaster;
import org.techhub.AKSupermart.model.BakeryitemsModel;
import org.techhub.AKSupermart.model.CartItem;
import org.techhub.AKSupermart.model.ClothesModel;
import org.techhub.AKSupermart.model.ContactForm;
import org.techhub.AKSupermart.model.CustomerMaster;
import org.techhub.AKSupermart.model.ElectronicitemsModel;
import org.techhub.AKSupermart.model.GroceryModel;
import org.techhub.AKSupermart.model.KitchenitemsModel;
import org.techhub.AKSupermart.model.OrderMaster;
import org.techhub.AKSupermart.model.ProductMaster;
import org.techhub.AKSupermart.model.RegisterMaster;
@Controller
public class RegisterController {

    @Autowired
    private RegisterService regService;
    
    @Autowired
    private CustomerService custService;
    
    @Autowired
    private AdminService adminService;
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private OrderService orderService;
    
    @Autowired
    private RecommendationService recommendationService;
    
    @Autowired
    private ContactService contService;
    
   
    
    
    @RequestMapping(value = "/")
    public ModelAndView test(HttpServletResponse response) throws IOException {
        return new ModelAndView("Homepage");
    }
    
    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public String showAdminPage() {
        return "adminlogin";
    }

   
    @RequestMapping(value = "/ad", method = RequestMethod.POST)
    public String showadminpage(AdminMaster ad, Model model) {
        boolean b = adminService.isAdminlogin(ad);
        if (b) {
            model.addAttribute("msg", "Registration Success............");
            return "admin";
        } else {
            model.addAttribute("msg", "Registration Failed...............");
            return "adminlogin";
        }       
        
    }
    
    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String showRegisterPage() {
        return "Register";
    }

    
    @RequestMapping(value = "/reg", method = RequestMethod.POST)
    public String saveData(RegisterMaster register, Model model) {
        boolean b = regService.isAddRegister(register);
        if (b) {
            model.addAttribute("msg", "Registration Success............");
            return "login";
        } else {
            model.addAttribute("msg", "Registration Failed...............");
            return "Register";
        }      
    }


    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String showLoginPage() {
        return "login";
    }

    
//    @RequestMapping(value = "/log", method = RequestMethod.POST)
//    public String handleLogin(CustomerMaster cust, Model model) {
//
//        boolean isValidUser = custService.isCustlogin(cust);
//        if (isValidUser) {
//            model.addAttribute("msg", "Login Success............");
//        	    List<ProductMaster> allProducts = productService.getProducts();
//
//        	    // Create lists for categories
//        	    List<ProductMaster> grocery = new ArrayList<ProductMaster>();
//        	    List<ProductMaster> clothes = new ArrayList<ProductMaster>();
//        	    List<ProductMaster> kitchenItems = new ArrayList<ProductMaster>();
//        	    List<ProductMaster> electronics = new ArrayList<ProductMaster>();
//        	    List<ProductMaster> bakery = new ArrayList<ProductMaster>();
//
//        	    for (ProductMaster product : allProducts) {
//        	        switch (product.getCatId()) {
//        	            case 1:
//        	                grocery.add(product);
//        	                break;
//        	            case 2:
//        	                clothes.add(product);
//        	                break;
//        	            case 3:
//        	                kitchenItems.add(product);
//        	                break;
//        	            case 4:
//        	            	electronics.add(product);
//        	            	break;
//        	            case 5: 
//        	                bakery.add(product);
//        	                break;
//        	            default:
//        	                break;
//        	        }
//        	    }
//
//        	   
//        	    model.addAttribute("grocery", grocery);
//        	    model.addAttribute("clothes", clothes);
//        	    model.addAttribute("kitchenItems", kitchenItems);
//        	    model.addAttribute("electronics", electronics);
//        	    model.addAttribute("bakeryitems", bakery);
//
//        	    return "Homepage";
//        	
//            
//        } else {
//            model.addAttribute("msg", "Login Failed. Invalid credentials.");
//            return "login"; 
//        }
//    }
    
    @RequestMapping(value = "/addproducts")
	public String addproducts() {
		return "addproducts";
	}
    
    
        
    @RequestMapping(value = "/AddproductsServlet", method = RequestMethod.POST)
    public String getCall(ProductMaster model, GroceryModel groceryModel, ClothesModel clothesModel, KitchenitemsModel kitchenModel, ElectronicitemsModel electronicModel, BakeryitemsModel bakeryModel, Map<String, Object> map, HttpServletRequest request) {
        boolean isProductAdded = false; 
        boolean isProductMasterAdded = productService.addproducts(model);
        if (isProductMasterAdded) {
            int categoryId = model.getCatId(); 
            switch (categoryId) {
                case 1: // Grocery
                    String mfdate = request.getParameter("mfdate");
                    String expdate = request.getParameter("expdate");
                    String weight= request.getParameter("weight");
                    groceryModel.setProdID(model.getProdID());
                    groceryModel.setCatid(model.getCatId());
                    groceryModel.setMfdate(mfdate);
                    groceryModel.setExpdate(expdate);
                    groceryModel.setWeight(weight);
                    isProductAdded = productService.isAddGrocery(groceryModel);
                    break;

                case 2: // Clothes
                    String size = request.getParameter("size");
                    String color = request.getParameter("colour");
                    String brand = request.getParameter("cbrand");
                    clothesModel.setProdID(model.getProdID());
                    clothesModel.setCatid(model.getCatId());
                    clothesModel.setSize(size);
                    clothesModel.setColour(color);
                    clothesModel.setCbrand(brand);
                    isProductAdded = productService.isAddClothes(clothesModel);
                    break;

                case 3: // Kitchen Items
                    String material = request.getParameter("KMaterial");
                    String kitchenBrand = request.getParameter("KBrand");
                    kitchenModel.setProdID(model.getProdID());
                    kitchenModel.setCatid(model.getCatId());
                    kitchenModel.setKMaterial(material);
                    kitchenModel.setKBrand(kitchenBrand);
                    isProductAdded = productService.isAddKitchenItems(kitchenModel);
                    break;

                case 4: // Electronic Items
                    String electronicBrand = request.getParameter("EBrand");
                    String warranty = request.getParameter("EWarranty");
                    electronicModel.setProdID(model.getProdID());
                    electronicModel.setCatid(model.getCatId());
                    electronicModel.setEBrand(electronicBrand);
                    electronicModel.setEWarranty(warranty);
                    isProductAdded = productService.isAddElectronicItems(electronicModel);
                    break;

                case 5: // Bakery Items
                    String bakeryMfdate = request.getParameter("bmfdate");
                    String bakeryExpdate = request.getParameter("bexpdate");
                    bakeryModel.setProdID(model.getProdID());
                    bakeryModel.setCatid(model.getCatId());
                    bakeryModel.setBmfdate(bakeryMfdate);
                    bakeryModel.setBexpdate(bakeryExpdate);
                    isProductAdded = productService.isAddBakeryItems(bakeryModel);
                    break;

                default:
                    map.put("msg", "Invalid Category");
                    return "addproducts";
            }

            if (isProductAdded) {
                map.put("msg", "Product Added Successfully");
            } else {
                map.put("msg", "Product added to ProductMaster, but failed to add to category table");
            }
        } else {
            map.put("msg", "Failed to add product to ProductMaster");
        }

        return "addproducts";
    }
    
    @RequestMapping("/Homepage")
    public String showHomepage(Model model) {
        List<ProductMaster> products = productService.getAllProducts();
        System.out.println("Products retrieved: " + products); 
        model.addAttribute("products", products);
        return "Homepage";
    }
    
    public List<ProductMaster> getProducts() {
    	List<ProductMaster> list = productService.getProducts();
    	return list;
    }


    	@RequestMapping(value = "/", method = RequestMethod.GET)
    	public String showProducts(Model model) {
    	    List<ProductMaster> allProducts = productService.getProducts();

    	    // Create lists for categories
    	    List<ProductMaster> grocery = new ArrayList<ProductMaster>();
    	    List<ProductMaster> clothes = new ArrayList<ProductMaster>();
    	    List<ProductMaster> kitchenItems = new ArrayList<ProductMaster>();
    	    List<ProductMaster> electronics = new ArrayList<ProductMaster>();
    	    List<ProductMaster> bakery = new ArrayList<ProductMaster>();

    	    for (ProductMaster product : allProducts) {
    	        switch (product.getCatId()) {
    	            case 1:
    	                grocery.add(product);
    	                break;
    	            case 2:
    	                clothes.add(product);
    	                break;
    	            case 3:
    	                kitchenItems.add(product);
    	                break;
    	            case 4:
    	            	electronics.add(product);
    	            	break;
    	            case 5: 
    	                bakery.add(product);
    	                break;
    	            default:
    	                break;
    	        }
    	    }

    	   
    	    model.addAttribute("grocery", grocery);
    	    model.addAttribute("clothes", clothes);
    	    model.addAttribute("kitchenItems", kitchenItems);
    	    model.addAttribute("electronics", electronics);
    	    model.addAttribute("bakeryitems", bakery);

    	    return "Homepage";
    	}

	
	public List<ProductMaster> getAllProducts() {
		List<ProductMaster> list = productService.getAllProducts();
		return list;
	}

	@RequestMapping(value = "/viewAllproduct")
	public String viewAllproduct(Map map) {
		map.put("productlist", this.getAllProducts());
		return "viewProducts";
	}

	@RequestMapping("/delProductById")
	public String deleteProductById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
	    productService.deleteProductById(prodid);
	    map.put("productlist", this.getAllProducts());
	    return "viewProducts";
	}
	
	@RequestMapping(value = "/addcustomer")
	public String addUser() {
		return "addcustomer";
	}

	@RequestMapping(value = "/AddCustomerServlet")
	public String getUser(CustomerMaster umodel, Map map) {
		boolean b = custService.isaddCustomer(umodel);
		if (b) {
			map.put("msg", "user Added");

		} else {
			map.put("msg", "Some Problem while adding");

		}
		return "addcustomer";

	}
	public List<CustomerMaster> getAllCustomer() {
		List<CustomerMaster> list = custService.getAllCustomer();
		return list;
	}

	@RequestMapping(value = "/viewAllCustomer")
	public String viewAllCustomer(Map map) {
		map.put("customerlist", this.getAllCustomer());
		return "viewcustomer";
	}
	
	@RequestMapping("/delCustomerById")
	public String deleteCustomerById(@RequestParam("custid") String custid, Map<String, Object> map) {
	    custService.deleteCustomerById(custid);
	    map.put("customerlist", this.getAllCustomer());
	    return "viewcustomer";
	}
	
	public List<GroceryModel> getgroceryitems() {
		List<GroceryModel> list = productService.getgroceryitems();
		return list;
	}

	@RequestMapping(value = "/viewgroceryitems")
	public String viewgroceryitems(Map map) {
		map.put("groceryitemslist", this.getgroceryitems());
		return "viewgroceryitems";
	}
	@RequestMapping("/delGrocryById")
	public String deleteGrocryById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
		productService.deleteGrocryById(prodid);
	    map.put("groceryitemslist", this.getgroceryitems());
	    return "viewgroceryitems";
	}
	@RequestMapping("/delClothesById")
	public String deleteClothesById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
	    productService.deleteClothesById(prodid);
	    map.put("clotheslist", this.getclothesitems());
	    return "viewclothesitems";
	}

	@RequestMapping("/delKitchenItemsById")
	public String deleteKitchenItemsById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
	    productService.deleteKitchenItemsById(prodid);
	    map.put("kitchenitemslist", this.getkitchenitems());
	    return "viewkitchenitems";
	}

	@RequestMapping("/delElectronicItemsById")
	public String deleteElectronicItemsById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
	    productService.deleteElectronicItemsById(prodid);
	    map.put("electronicitemslist", this.getelectronicitems());
	    return "viewelectronicitems";
	}

	@RequestMapping("/delBakeryItemsById")
	public String deleteBakeryItemsById(@RequestParam("prodid") String prodid, Map<String, Object> map) {
	    productService.deleteBakeryItemsById(prodid);
	    map.put("bakeryitemslist", this.getbakeryitems());
	    return "viewbakeryitems";
	}

	
	public List<ClothesModel> getclothesitems() {
		List<ClothesModel> list = productService.getclothesitems();
		return list;
	}

	@RequestMapping(value = "/viewclothesitems")
	public String viewclothesitems(Map map) {
		map.put("clothesitemslist", this.getclothesitems());
		return "viewclothesitems";
	}
	
	public List<KitchenitemsModel> getkitchenitems() {
		List<KitchenitemsModel> list = productService.getkitchenitems();
		return list;
	}

	@RequestMapping(value = "/viewkitchenitems")
	public String viewkitchenitems(Map map) {
		map.put("kitchenitemslist", this.getkitchenitems());
		return "viewkitchenitems";
	}
	
	public List<ElectronicitemsModel> getelectronicitems() {
		List<ElectronicitemsModel> list = productService.getelectronicitems();
		return list;
	}

	@RequestMapping(value = "/viewelectronicitems")
	public String viewelectronicitems(Map map) {
		map.put("electronicitemslist", this.getelectronicitems());
		return "viewelectronicitems";
	}
	
	public List<BakeryitemsModel> getbakeryitems() {
		List<BakeryitemsModel> list = productService.getbakeryitems();
		return list;
	}

	@RequestMapping(value = "/viewbakeryitems")
	public String viewbakeryitems(Map map) {
		map.put("bakeryitemslist", this.getbakeryitems());
		return "viewbakeryitems";
	}
	 
	@RequestMapping(value = "/searchProducts", method = RequestMethod.GET)
    public String searchProducts(@RequestParam("name") String name, Model model) {
        List<ProductMaster> productList = productService.searchProductsByName(name);
        model.addAttribute("productlist", productList);
        return "viewProducts";
    }
	
	@RequestMapping(value = "/searchCustomer", method = RequestMethod.GET)
    public String searchCustomer(@RequestParam("name") String name, Model model) {
        List<CustomerMaster> productList = custService.searchCustomerByName(name);
        model.addAttribute("customerlist", productList);
        return "viewcustomer";
    }
    
	@RequestMapping(value = "/searchGroceryItems", method = RequestMethod.GET)
	public String searchGroceryItems(@RequestParam("prodID") String prodID, Model model) {
	    List<GroceryModel> groceryItemsList = productService.searchGroceryItemsByProdID(prodID);
	    model.addAttribute("groceryitemslist", groceryItemsList);
	    return "viewgroceryitems"; 
	}
	
	@RequestMapping(value = "/searchClothesItems", method = RequestMethod.GET)
	public String searchClothesItems(@RequestParam("prodID") String prodID, Model model) {
	    List<ClothesModel> clothesItemsList = productService.searchClothesItemsByProdID(prodID);
	    model.addAttribute("clothesitemslist", clothesItemsList);
	    return "viewclothesitems";
	}

	@RequestMapping(value = "/searchKitchenItems", method = RequestMethod.GET)
	public String searchKitchenItems(@RequestParam("prodID") String prodID, Model model) {
	    List<KitchenitemsModel> kitchenItemsList = productService.searchKitchenItemsByProdID(prodID);
	    model.addAttribute("kitchenitemslist", kitchenItemsList);
	    return "viewkitchenitems";
	}

	@RequestMapping(value = "/searchElectronicItems", method = RequestMethod.GET)
	public String searchElectronicItems(@RequestParam("prodID") String prodID, Model model) {
	    List<ElectronicitemsModel> electronicItemsList = productService.searchElectronicItemsByProdID(prodID);
	    model.addAttribute("electronicitemslist", electronicItemsList);
	    return "viewelectronicitems";
	}

	@RequestMapping(value = "/searchBakeryItems", method = RequestMethod.GET)
	public String searchBakeryItems(@RequestParam("prodID") String prodID, Model model) {
	    List<BakeryitemsModel> bakeryItemsList = productService.searchBakeryItemsByProdID(prodID);
	    model.addAttribute("bakeryitemslist", bakeryItemsList);
	    return "viewbakeryitems";
	}
    
    
	 @RequestMapping(value = "/editProduct", method = RequestMethod.GET)
	    public String showUpdateProductForm(@RequestParam("prodid") String prodid, Model model) {
	        ProductMaster product = productService.getProductById(prodid);
	        if (product != null) {
	            model.addAttribute("product", product);
	            return "updateproduct"; 
	        } else {
	            model.addAttribute("msg", "Product not found");
	            return "viewProducts";
	        }
	    }

	 @RequestMapping(value = "/updateproduct", method = RequestMethod.POST)
	 public String updateProduct(@ModelAttribute("product") ProductMaster updatedProduct, Model model) {
	     boolean isUpdated = productService.updateProduct(updatedProduct);
	     if (isUpdated) {
	         model.addAttribute("msg", "Product updated successfully");
	         List<ProductMaster> productList = productService.getAllProducts();
	         model.addAttribute("productlist", productList);
	         return "viewProducts";
	     } else {
	         model.addAttribute("msg", "Failed to update product");
	         return "updateproduct"; 
	     }
	 }
	 @RequestMapping(value = "/editCustomer" , method = RequestMethod.GET)
	    public String showUpdateForm(@RequestParam("custid") int id, Model model) {
	        CustomerMaster customer = custService.getCustomerById(id);
	        if(customer != null) {
	        	model.addAttribute("customer", customer);
	        	return "updateCustomer";
	        }
	        else {
	            model.addAttribute("msg", "Customer not found");
	            return "viewcustomer";
	        }  
	    }
	 @RequestMapping("/updateCustomer")
	    public String updateCustomer(@ModelAttribute("customer") CustomerMaster updatedCustomer, Model model) {
		     boolean isUpdated = custService.updateCustomer(updatedCustomer);
		     if (isUpdated) {
		         model.addAttribute("msg", "Customer updated successfully");
		         List<CustomerMaster> productList = custService.getAllCustomer();
		         model.addAttribute("customerlist", productList);
		         return "viewcustomer";
		     } else {
		         model.addAttribute("msg", "Failed to update product");
		         return "updateCustomer"; 
		     }
	    }
	 
	 @RequestMapping(value = "/editGroceryItem", method = RequestMethod.GET)
	 public String showUpdateGroceryItemForm(@RequestParam("prodid") String prodid, Model model) {
	     GroceryModel groceryItem = productService.getGroceryItemById(prodid);
	     if (groceryItem != null) {
	         model.addAttribute("groceryitemslist", groceryItem);
	         return "updateGroceryItem";
	     } else {
	         model.addAttribute("msg", "Grocery item not found");
	         return "viewgroceryitems";
	     }
	 }

	 @RequestMapping(value = "/updateGroceryItem", method = RequestMethod.POST)
	 public String updateGroceryItem(@ModelAttribute("groceryitemslist") GroceryModel updatedGroceryItem, Model model) {
	     boolean isUpdated = productService.updateGroceryItem(updatedGroceryItem);
	     if (isUpdated) {
	         model.addAttribute("msg", "Grocery item updated successfully");
	         List<GroceryModel> grocerylist=productService.getgroceryitems();
	         model.addAttribute("groceryitemslist", grocerylist);
	         return "viewgroceryitems";  
	     } else {
	         model.addAttribute("msg", "Failed to update grocery item");
	         return "updateGroceryItem";
	     }
	 }

	    // Update Clothes Item
	    @RequestMapping(value = "/editClothesItem", method = RequestMethod.GET)
	    public String showUpdateClothesItemForm(@RequestParam("prodid") String prodid, Model model) {
	        ClothesModel clothesItem = productService.getClothesItemById(prodid);
	        if (clothesItem != null) {
	            model.addAttribute("clothesitemslist", clothesItem);
	            return "updateClothesItem";
	        } else {
	            model.addAttribute("msg", "Clothes item not found");
	            return "viewclothesitems";
	        }
	    }

	    @RequestMapping(value = "/updateClothesItem", method = RequestMethod.POST)
	    public String updateClothesItem(@ModelAttribute("clothesItem") ClothesModel updatedClothesItem, Model model) {
	        boolean isUpdated = productService.updateClothesItem(updatedClothesItem);
	        if (isUpdated) {
	            model.addAttribute("msg", "Clothes item updated successfully");
	            List<ClothesModel> clotheslist = productService.getclothesitems();
	            model.addAttribute("clothesitemslist",clotheslist);
	            return "viewclothesitems";
	        } else {
	            model.addAttribute("msg", "Failed to update clothes item");
	            return "updateClothesItem";
	        }
	    }

	    // Update Kitchen Item
	    @RequestMapping(value = "/editKitchenItem", method = RequestMethod.GET)
	    public String showUpdateKitchenItemForm(@RequestParam("prodid") String prodid, Model model) {
	        KitchenitemsModel kitchenItem = productService.getKitchenItemById(prodid);
	        if (kitchenItem != null) {
	            model.addAttribute("kitchenitemslist", kitchenItem);
	            return "updateKitchenItem";
	        } else {
	            model.addAttribute("msg", "Kitchen item not found");
	            return "viewkitchenitems";
	        }
	    }

	    @RequestMapping(value = "/updateKitchenItem", method = RequestMethod.POST)
	    public String updateKitchenItem(@ModelAttribute("kitchenItem") KitchenitemsModel updatedKitchenItem, Model model) {
	        boolean isUpdated = productService.updateKitchenItems(updatedKitchenItem);
	        if (isUpdated) {
	            model.addAttribute("msg", "Kitchen item updated successfully");
	            List<KitchenitemsModel> list = productService.getkitchenitems();
	            model.addAttribute("kitchenitemslist", list);
	            return "viewkitchenitems";
	        } else {
	            model.addAttribute("msg", "Failed to update kitchen item");
	            return "updateKitchenItem";
	        }
	    }

	    // Update Electronic Item
	    @RequestMapping(value = "/editElectronicItem", method = RequestMethod.GET)
	    public String showUpdateElectronicItemForm(@RequestParam("prodid") String prodid, Model model) {
	        ElectronicitemsModel electronicItem = productService.getElectronicItemById(prodid);
	        if (electronicItem != null) {
	            model.addAttribute("electronicitemslist", electronicItem);
	            return "updateElectronicItem";
	        } else {
	            model.addAttribute("msg", "Electronic item not found");
	            return "viewelectronicitems";
	        }
	    }

	    @RequestMapping(value = "/updateElectronicItem", method = RequestMethod.POST)
	    public String updateElectronicItem(@ModelAttribute("electronicItem") ElectronicitemsModel updatedElectronicItem, Model model) {
	        boolean isUpdated = productService.updateElectronicItems(updatedElectronicItem);
	        if (isUpdated) {
	            model.addAttribute("msg", "Electronic item updated successfully");
	            List<ElectronicitemsModel> list = productService.getelectronicitems();
	            model.addAttribute("electronicitemslist", list);
	            return "viewelectronicitems";
	        } else {
	            model.addAttribute("msg", "Failed to update electronic item");
	            return "updateElectronicItem";
	        }
	    }

	    // Update Bakery Item
	    @RequestMapping(value = "/editBakeryItem", method = RequestMethod.GET)
	    public String showUpdateBakeryItemForm(@RequestParam("prodid") String prodid, Model model) {
	        BakeryitemsModel bakeryItem = productService.getBakeryItemById(prodid);
	        if (bakeryItem != null) {
	            model.addAttribute("bakeryitemslist", bakeryItem);
	            return "updateBakeryItem";
	        } else {
	            model.addAttribute("msg", "Bakery item not found");
	            return "viewbakeryitems";
	        }
	    }

	    @RequestMapping(value = "/updateBakeryItem", method = RequestMethod.POST)
	    public String updateBakeryItem(@ModelAttribute("bakeryItem") BakeryitemsModel updatedBakeryItem, Model model) {
	        boolean isUpdated = productService.updateBakeryItems(updatedBakeryItem);
	        if (isUpdated) {
	            model.addAttribute("msg", "Bakery item updated successfully");
	            List<BakeryitemsModel> list = productService.getbakeryitems();
	            model.addAttribute("bakeryitemslist", list);
	            return "viewbakeryitems";
	        } else {
	            model.addAttribute("msg", "Failed to update bakery item");
	            return "updateBakeryItem";
	        }
	    }
	    
		public List<OrderMaster> getAllOrder() {
			List<OrderMaster> orderlist = orderService.getAllOrder();
			return orderlist;
		}

		
		@RequestMapping(value = "/viewAllOrder")
		public String viewAllOrder(Map map) {
		    map.put("orderlist", this.getAllOrder());
		    return "vieworder";
		}
        
	

		@RequestMapping(value = "/addToCart", method = RequestMethod.POST)
	    public String addToCart(
	            @RequestParam("productName") String productName,
	            @RequestParam("custId") int custId,
	            @RequestParam("quantity") int quantity,
	            Model model) {
	        boolean orderSaved = orderService.processOrder(productName, custId, quantity);
			if (orderSaved) {
			    model.addAttribute("message", "Order placed successfully.");
			} else {
			    model.addAttribute("message", "Failed to place order.");
			}
	        return "orderConfirmation";
	    }
		
		 // Method to add product to cart
	    @RequestMapping(value = "/Cart", method = RequestMethod.GET)
	    public String Cart(@RequestParam("prodID") String prodID,
	                       @RequestParam("prodName") String prodName,
	                       @RequestParam("price") double price,
	                       @RequestParam("quantity") int quantity,
	                       Model model) {

	        // Set product details
	        ProductMaster product = new ProductMaster();
	        product.setProdID(prodID);
	        product.setProdName(prodName);
	        product.setPrice(price);
	        product.setQuantity(quantity);
	       
	        
	        // Add the product to the cart
	        orderService.addProductToCart(product);

	        // Redirect to the showCart method
	        return "redirect:/showCart";
	    }

	    // Method to show cart items
	    @RequestMapping(value = "/showCart", method = RequestMethod.GET)
	    public String showCart(Model model) {
	        // Fetch cart items and add them to the model
	        model.addAttribute("cartItems", orderService.getCartItems());
	        return "cart";  // Return cart.jsp to display cart items
	    }
		    

		    @RequestMapping("/confirmPayment")
		    public String confirmPayment() {
		        orderService.confirmOrder();
		        return "redirect:/thankYou";  // Redirect to thank you page
		    }

		    @RequestMapping("/payment")
		    public String showPaymentPage() {
		        return "payment";  // Redirect to payment.jsp
		    }
		
		
//		@RequestMapping(value = "/cart", method = RequestMethod.GET)
//		public String cart(@RequestParam("prodID") String prodId, 
//		                   @RequestParam("custid") int custId, 
//		                   Model model) {
//		    try {
//		        // Retrieve the product and customer information
//		        ProductMaster product = productService.getProductById(prodId);
//		        CustomerMaster customer = custService.getCustomerById(custId);
//
//		        // Handle the case if product or customer is not found
//		        if (product == null) {
//		            model.addAttribute("error", "Product not found!");
//		            return "error"; // Forward to an error page
//		        }
//
//		        if (customer == null) {
//		            model.addAttribute("error", "Customer not found!");
//		            return "error"; // Forward to an error page
//		        }
//
//		        // Create a new order
//		        OrderMaster order = new OrderMaster();
//		        order.setProdId(product.getProdID());
//		        order.setCustId(customer.getCustid());
//		        order.setOrdDate(new java.sql.Date(System.currentTimeMillis()));
//		        order.setTotalAmount(product.getPrice());
//
//		        // Save the order using the service
//		        boolean isAdded = orderService.addorder(order);
//		        if (!isAdded) {
//		            model.addAttribute("error", "Failed to add product to cart.");
//		            return "error"; // Forward to an error page
//		        }
//
//		        // Retrieve all orders (cart items) after adding the new order
//		        List<OrderMaster> cartItems = orderService.getAllOrder();
//		        model.addAttribute("cartItems", cartItems);  // Add the cart items to the model
//
//		        // Redirect to the cart page with the cart items
//		        return "cart";  // This will forward to cart.jsp
//
//		    } catch (Exception e) {
//		        model.addAttribute("error", "An error occurred: " + e.getMessage());
//		        return "error"; // Forward to an error page
//		    }
//		}


		
		
		@RequestMapping(value = "/log", method = RequestMethod.POST)
		public String handleLogin(CustomerMaster cust, HttpServletRequest request, Model model) {
		    boolean isValidUser = custService.isCustlogin(cust);

		    if (isValidUser) {
		        // Store user in session
		        HttpSession session = request.getSession();
		        CustomerMaster loggedInUser = custService.getCustomerByEmail(cust.getEmail());
		        session.setAttribute("loggedInUser", loggedInUser); // Store logged in user in session

		        model.addAttribute("msg", "Login Success............");

		        List<ProductMaster> allProducts = productService.getProducts();
		        List<ProductMaster> grocery = new ArrayList<ProductMaster>();
		        List<ProductMaster> clothes = new ArrayList<ProductMaster>();
		        List<ProductMaster> kitchenItems = new ArrayList<ProductMaster>();
		        List<ProductMaster> electronics = new ArrayList<ProductMaster>();
		        List<ProductMaster> bakery = new ArrayList<ProductMaster>();

		        for (ProductMaster product : allProducts) {
		            switch (product.getCatId()) {
		                case 1:
		                    grocery.add(product);
		                    break;
		                case 2:
		                    clothes.add(product);
		                    break;
		                case 3:
		                    kitchenItems.add(product);
		                    break;
		                case 4:
		                    electronics.add(product);
		                    break;
		                case 5:
		                    bakery.add(product);
		                    break;
		                default:
		                    break;
		            }
		        }

		        model.addAttribute("grocery", grocery);
		        model.addAttribute("clothes", clothes);
		        model.addAttribute("kitchenItems", kitchenItems);
		        model.addAttribute("electronics", electronics);
		        model.addAttribute("bakeryitems", bakery);

		        return "Homepage";

		    } else {
		        model.addAttribute("msg", "Login Failed. Invalid credentials.");
		        return "login";
		    }
		}

		@RequestMapping("/myprofile")
		public String showUserProfile(HttpServletRequest request, Model model) {
		    HttpSession session = request.getSession();
		    CustomerMaster user = (CustomerMaster) session.getAttribute("loggedInUser");

		    if (user != null) {
		        model.addAttribute("user", user);  // Pass user data to the view
		        return "myprofile";  // profile.jsp will be rendered
		    } else {
		        return "redirect:/login";  // Redirect to login if no user is in session
		    }
		}

		 @RequestMapping("/logout")
		    public String logoutUser(HttpServletRequest request) {
		        HttpSession session = request.getSession(false);
		        if (session != null) {
		            session.invalidate();  // Invalidate session to logout
		        }
		        return "redirect:/login";  // Redirect to login page after logout
		    }
		 
		 
		 @RequestMapping(value = "/getrecommendation")
		    public String getrecommendation() {
		        return "recommendations";  // This opens recommendationmovie.jsp
		    }


		    @RequestMapping(value = "/getrecommendation", method = RequestMethod.POST)
		    public String getRecommendedProduct(@RequestParam("productName") String productName, Model model) {
		        System.out.println("Product name received: " + productName);

		        // Fetch recommended products from the service based on the product name
		        List<ProductMaster> recommendedProducts = recommendationService.getRecommendations(productName);

		        if (recommendedProducts.isEmpty()) {
		            // If no recommendations found, send an error message
		            model.addAttribute("error", "No recommendations available for the entered product.");
		        } else {
		            // Add the recommended products to the model to pass to the JSP page
		            model.addAttribute("recommendedProducts", recommendedProducts);
		        }

		        // Return the view name to display recommendations
		        return "recommendations";  // This will resolve to recommendations.jsp
		    }
		    
		    
		    @RequestMapping(value = "/search")
		    public String search(@RequestParam("name") String productName, Model model) {
		        System.out.println("Product name received: " + productName);

		        // Fetch all products for category display
		        List<ProductMaster> allProducts = productService.getProducts();

		        // Create lists for categories
		        List<ProductMaster> grocery = new ArrayList<ProductMaster>();
		        List<ProductMaster> clothes = new ArrayList<ProductMaster>();
		        List<ProductMaster> kitchenItems = new ArrayList<ProductMaster>();
		        List<ProductMaster> electronics = new ArrayList<ProductMaster>();
		        List<ProductMaster> bakery = new ArrayList<ProductMaster>();

		        // Populate category lists
		        for (ProductMaster product : allProducts) {
		            switch (product.getCatId()) {
		                case 1:
		                    grocery.add(product);
		                    break;
		                case 2:
		                    clothes.add(product);
		                    break;
		                case 3:
		                    kitchenItems.add(product);
		                    break;
		                case 4:
		                    electronics.add(product);
		                    break;
		                case 5:
		                    bakery.add(product);
		                    break;
		                default:
		                    break;
		            }
		        }

		        // Add category lists to the model
		        model.addAttribute("grocery", grocery);
		        model.addAttribute("clothes", clothes);
		        model.addAttribute("kitchenItems", kitchenItems);
		        model.addAttribute("electronics", electronics);
		        model.addAttribute("bakeryitems", bakery);

		        // Fetch the product details based on the product name
		        ProductMaster product = productService.getProductByName(productName);

		        if (product == null) {
		            // If no product found, set an error message and an empty list for recommendations
		            model.addAttribute("error", "No product found with the name: " + productName);
		            model.addAttribute("recommendedProducts", new ArrayList<ProductMaster>());
		        } else {
		            // Fetch recommended products based on the product name
		            List<ProductMaster> recommendedProducts = recommendationService.getRecommendations(productName);

		            // Add the searched product and recommended products to the model
		            model.addAttribute("product", product);
		            model.addAttribute("recommendedProducts", recommendedProducts);
		        }

		        // Return the view name to display the product and recommendations
		        return "Homepage";  // This resolves to homepage.jsp
		    }

		    
		   

		    @RequestMapping("/contact")
		    public String submitContactForm(@ModelAttribute ContactForm contactForm, Model model) {
		        contService.sendEmail(contactForm);
		        model.addAttribute("message", "Thank you for contacting us!");
		        return "Homepage"; // Assuming "contactSuccess.jsp" is your success page.
		    }


		 
	 
}
