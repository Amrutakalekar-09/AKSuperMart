package org.techhub.AKSupermart.Service;

import java.util.List;

import org.techhub.AKSupermart.model.OrderMaster;
import org.techhub.AKSupermart.model.ProductMaster;

public interface OrderService {
//	public boolean addorder(OrderMaster model);
	public List<OrderMaster> getAllOrder();
	
	public List<OrderMaster> getCustomerwiseOrders(int custId);
	public boolean processOrder(String productName, int custId, int quantity) ;
	 void addProductToCart(ProductMaster product);
	    List<ProductMaster> getCartItems();
	    void confirmOrder();
	   
	
}
