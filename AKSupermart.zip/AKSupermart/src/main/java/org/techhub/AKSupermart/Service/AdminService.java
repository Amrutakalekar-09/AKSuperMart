package org.techhub.AKSupermart.Service;

import org.techhub.AKSupermart.model.AdminMaster;

public interface AdminService {
	public boolean isAdminlogin(AdminMaster ad);
}
