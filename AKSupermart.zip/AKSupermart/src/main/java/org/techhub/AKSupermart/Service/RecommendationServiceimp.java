package org.techhub.AKSupermart.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.OrderRepository;
import org.techhub.AKSupermart.Repository.ProductRepository;
import org.techhub.AKSupermart.Repository.RecommendationRepository;
import org.techhub.AKSupermart.model.ProductMaster;

@Service
public class RecommendationServiceimp implements RecommendationService {
	@Autowired
    private ProductRepository prodRepo; 

    @Autowired
    private RecommendationRepository recommendationRepository;

    @Override
    public List<ProductMaster> getRecommendations(String productName) {
        List<ProductMaster> recommendations = new ArrayList<ProductMaster>();
        ProductMaster product = recommendationRepository.getProductIdByName(productName);  // Get product by name, not by ID
        if (product == null) {
            return recommendations; // Product not found
        }

        String productId = product.getProdID();
        List<Integer> customerIds = recommendationRepository.getCustomerIdsByProductId(productId);
        if (customerIds.isEmpty()) {
            return recommendations; // No customers found for this product
        }

        Map<String, Integer> productCountMap = new HashMap<String, Integer>();
        for (int customerId : customerIds) {
            List<String> otherProductIds = recommendationRepository.getOtherProductsByCustomerId(customerId, productId);
            for (String otherProductId : otherProductIds) {
                productCountMap.put(otherProductId, productCountMap.getOrDefault(otherProductId, 0) + 1);
            }
        }

        // Convert the map to a list and sort by frequency
        List<Map.Entry<String, Integer>> entryList = new ArrayList<Entry<String, Integer>>(productCountMap.entrySet());

        Collections.sort(entryList, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                return b.getValue().compareTo(a.getValue());  // Sort by frequency in descending order
            }
        });

        // Add sorted products to the recommendations list
        for (Map.Entry<String, Integer> entry : entryList) {
            ProductMaster recommendedProduct = new ProductMaster();
            recommendedProduct.setProdName(entry.getKey());
            recommendedProduct.setQuantity(entry.getValue()); // Store the frequency
            recommendations.add(recommendedProduct);
        }

        return recommendations;
    }

	@Override
	public ProductMaster getProductByName(String productName) {
		// TODO Auto-generated method stub
		return recommendationRepository.getProductByName(productName);
	}

	
}
