package org.techhub.AKSupermart.model;

public class KitchenitemsModel extends ProductMaster{
	private int srno;
    private String prodID;
    public  KitchenitemsModel() {
    	
    }
    public  KitchenitemsModel(int srno,String prodID,String KMaterial,String KBrand) {
    	this.srno=srno;
    	this.prodID=prodID;
    	this.catid=catid;
    	this.KBrand=KBrand;
    	this.KMaterial=KMaterial;
    }
    public int getSrno() {
		return srno;
	}
	public void setSrno(int srno) {
		this.srno = srno;
	}
	public String getProdID() {
		return prodID;
	}
	public void setProdID(String prodID) {
		this.prodID = prodID;
	}
	private int catid;
    private String KMaterial;
    private String KBrand;
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getKMaterial() {
		return KMaterial;
	}
	public void setKMaterial(String kMaterial) {
		KMaterial = kMaterial;
	}
	public String getKBrand() {
		return KBrand;
	}
	public void setKBrand(String kBrand) {
		KBrand = kBrand;
	}
	
}
