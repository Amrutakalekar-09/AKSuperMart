package org.techhub.AKSupermart.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.OrderRepository;
import org.techhub.AKSupermart.Repository.ProductRepository;
import org.techhub.AKSupermart.model.OrderMaster;
import org.techhub.AKSupermart.model.ProductMaster;

@Service
public class OrderServiceimp implements OrderService{
	
	    @Autowired
	    private OrderRepository orderRepository;
	    
	    @Autowired
	    private ProductRepository productRepository;
	    
	    @Override
	    public boolean processOrder(String productName, int custId, int quantity) {
	        String prodId = productRepository.getProductId(productName);
	        double price = productRepository.getProductPrice(productName);
	        if (price != 0.0 && prodId != null) {
	            double totalAmount = price * quantity;
	            OrderMaster order = new OrderMaster(prodId, custId, new java.sql.Date(System.currentTimeMillis()), totalAmount);
	            return orderRepository.saveOrder(order);
	        }
	        return false;
	    }
	    @Override
	    public List<OrderMaster> getCustomerwiseOrders(int custId) {
	        return orderRepository.getCustomerwiseOrders(custId);
	    }
		
	    private List<ProductMaster> cartItems = new ArrayList<ProductMaster>();

	    @Override
	    public void addProductToCart(ProductMaster product) {
	        cartItems.add(product);
	    }

	    @Override
	    public List<ProductMaster> getCartItems() {
	        return cartItems;
	    }

	    @Override
	    public void confirmOrder() {
	        for (ProductMaster product : cartItems) {
	            OrderMaster order = new OrderMaster();
	            order.setProdId(product.getProdID());
	            order.setCustId(1); // Replace with actual customer ID from session or request
	            order.setOrdDate(new java.sql.Date(System.currentTimeMillis()));
	            order.setTotalAmount(product.getPrice() * product.getQuantity());
	            
	            orderRepository.saveOrder(order);
	        }
	        cartItems.clear(); // Clear the cart after saving the order
	    }

	   
//    @Override
//	public boolean addorder(OrderMaster model) {
//		return ordRepo.addorder(model);
//	}
//
	@Override
	public List<OrderMaster> getAllOrder() {
		return orderRepository.getAllOrder();
	}
	
	
	    
    
}
