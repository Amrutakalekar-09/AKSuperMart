package org.techhub.AKSupermart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.ContactRepository;

import org.techhub.AKSupermart.model.ContactForm;

@Service
public class ContactServiceimp implements ContactService{

	@Autowired
    private ContactRepository contRepo; 
	
	@Override
	public void sendEmail(ContactForm contactForm) {
		 contRepo.sendEmail(contactForm);
		
	}

}
