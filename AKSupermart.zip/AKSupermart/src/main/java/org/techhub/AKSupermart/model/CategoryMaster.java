package org.techhub.AKSupermart.model;

public class CategoryMaster {
    private int CatID;
    private String Name;
	public int getCatID() {
		return CatID;
	}
	public void setCatID(int catID) {
		CatID = catID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
}
