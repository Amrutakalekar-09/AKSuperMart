package org.techhub.AKSupermart.Repository;

import java.util.List;

import org.techhub.AKSupermart.model.OrderMaster;

public interface OrderRepository {
//	public boolean addorder(OrderMaster model);
	public List<OrderMaster> getAllOrder();
	public boolean saveOrder(OrderMaster order);
	public List<OrderMaster> getCustomerwiseOrders(int custId);
	
   
   
}
