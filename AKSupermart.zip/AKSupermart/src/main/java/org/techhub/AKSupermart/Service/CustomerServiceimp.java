package org.techhub.AKSupermart.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.AKSupermart.Repository.CustomerRepository;
import org.techhub.AKSupermart.model.CustomerMaster;
@Service
public class CustomerServiceimp implements CustomerService{
	@Autowired
    private CustomerRepository custRepo;
	
	@Override
	public boolean isCustlogin(CustomerMaster cust) {
		return custRepo.isCustlogin(cust);
	}

	@Override
	public boolean isaddCustomer(CustomerMaster umodel) {
		return custRepo.isaddCustomer(umodel);
	}

	@Override
	public List<CustomerMaster> getAllCustomer() {
		return custRepo.getAllCustomer();
	}

	@Override
	public void deleteCustomerById(String id) {
		custRepo.deleteCustomerById(id);
		
	}

	@Override
	public CustomerMaster getCustomerById(int custId) {
		
		return custRepo.getCustomerById(custId);
	}

	@Override
	public CustomerMaster getCustomerByEmail(String email) {
	
		return custRepo.getCustomerByEmail(email);
	}

	@Override
	public boolean updateCustomer(CustomerMaster cust) {
		
		return custRepo.updateCustomer(cust);
	}

	@Override
	public List<CustomerMaster> searchCustomerByName(String name) {
		
		return custRepo.searchCustomerByName(name);
	}
}
